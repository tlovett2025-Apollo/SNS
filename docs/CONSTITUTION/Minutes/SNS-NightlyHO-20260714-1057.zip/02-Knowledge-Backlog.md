# Stock & Stir Knowledge Backlog

## Inventory Modeling
- Expandable quadrant streams: required because the catalog will outgrow a static grid.
- Search and food-family grouping: needed for mobile usability and low cognitive load.
- Specific identity beneath broad labels: Fresh Greens should guide discovery, but planning must know spinach, kale, chard, lettuce, or another exact ingredient.
- Quantity evolution: exact counts, weight, package size, freshness, and expiration may later extend None/A little/Plenty.
- Inventory provenance: future records may come from manual entry, receipts, photographs, barcodes, or remembered purchasing patterns.

## Equipment Knowledge
- Capture burners, oven, microwave, rice cooker, pressure cooker, slow cooker, air fryer, grill, blender, food processor, large soup pot, sheet pans, and casserole dishes.
- Later capture capacity and limitations, not just possession.

## Skill and Teaching Profile
- Begin with Learning, Comfortable, and Experienced.
- Later distinguish knife, stovetop, oven, raw-meat, timing, and improvisation confidence.
- Eventually adapt teaching depth as the user gains confidence.

## Spice and Salt Intelligence
- Spice KO training for pairing, flavor direction, heat, blooming, bitterness, and finishing.
- Salt-layering intelligence for broth, canned foods, cured meat, cheese, sauces, and commercial blends.
- Store-bought blends must indicate whether salt is a major component.

## Multiple Proteins and Breakfast
- Lead and supporting proteins.
- Sunny-side-up, over-easy, scrambled, omelet, boiled, poached, and baked egg knowledge.
- Beans as protein, foundation, side, or multiple roles.
- Breakfast as a meal shape, including simple meals such as egg, beans, and salsa.

## Authentication and Household Persistence
- Managed authentication.
- Household ownership.
- Trial start/end and entitlement state.
- Password recovery.

## Payments
- Stripe Checkout Sessions.
- Stripe Billing Portal Sessions.
- Webhook-driven subscription status.

## Public-to-App Integration
- GetRecipeList endpoint.
- GetRecipe endpoint.
- Versioned static-site/Python contracts independent of Streamlit state.

## Mobile UX
- Portrait-safe account actions.
- Collapsible inventory sections, sticky search, recent items, favorites, and selected-item summaries.

## Testing and Observability
- Contract tests.
- Hosted page smoke tests.
- Domain, certificate, and service-health monitoring.
