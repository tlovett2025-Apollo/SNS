# Stock & Stir Engineering Council Minutes
## 2026-07-14

### Mission
Stock & Stir helps ordinary households turn food they already own into practical meals without requiring perfect energy, equipment, confidence, or culinary knowledge. The product reduces cognitive load by remembering the household, understanding the kitchen, and translating available ingredients into realistic meal choices and coordinated cooking instructions.

### Product Philosophy
- Stock & Stir is cooking intelligence, not a recipe collection.
- Household memory is core product value.
- Guidance is useful but optional; a cook may omit a suggested seasoning or optional step.
- No cuisine selection does not mean unseasoned food.
- Encouragement belongs at the end of a useful instruction, not as a separate step.
- Observable doneness and realistic timing windows are preferred over false precision.
- Broad user-facing categories must not erase technically important cooking differences.

### Architecture Decisions
- The public website and Python application are separate Render services.
- The public customer flow is: Public Website → Login/Trial → My Kitchen → Recipe Choices → Generated Recipe.
- My Kitchen is persistent household memory.
- Initial inventory is organized into Pantry, Fridge, Freezer, and Fresh.
- Equipment belongs in My Kitchen as a separate section.
- Skill assessment belongs in onboarding/profile, not inside food inventory.
- Initial quantity bands are None, A little, and Plenty.
- A little means approximately one can, one package, or enough for one meal.
- GetRecipeList receives a full inventory snapshot.
- GetRecipe receives the selected recipe identifier plus the relevant kitchen snapshot.
- Future architecture must support lead and supporting proteins.
- Egg preparation requires explicit forms/techniques.

### Business Decisions
- One complete paid product; no deliberately weakened free tier.
- Seven-day free trial.
- $10/month.
- $100/year.
- Annual value may be described as about $0.27/day.
- Monthly value is about $0.33/day.
- Stripe-hosted Checkout and Billing Portal are the intended payment systems.

### User Experience Decisions
- The public site remains viewable without login.
- Returning users go to saved My Kitchen.
- New users go to guided My Kitchen setup.
- Mobile navigation includes How It Works, Features, Meal Ideas, Pricing, Log In, Start Free Trial, and About Us.
- Start Free Trial remains the emphasized mobile action.
- My Kitchen supports Save My Kitchen and Generate Recipes.
- Each inventory quadrant may become an independently expandable stream.
- Equipment is separate from food inventory.
- Skill level shapes instructional detail and terminology.

### Marketing Ideas
- Dinner starts with what the household already has.
- “Your kitchen should remember you.”
- Emphasize less decision fatigue, less food waste, household memory, low-energy support, and real cooking timelines.
- Annual pricing may be framed as about $0.27/day.

### Knowledge Base Evolution
- Future Spice KO training must represent flavor direction, salt contribution, commercial blends, salty ingredients, and salt layering.
- Neutral seasoning should vary by protein and meal shape.
- Fresh Greens requires a formal flexibility model. Kale, chard, spinach, and lettuce are not interchangeable in timing, heat tolerance, texture, or role.
- The CKB needs either specific ingredient identity beneath a broad family or a controlled substitution family with explicit constraints.
- Multiple-protein knowledge, breakfast meal shapes, beans as multi-role ingredients, and egg techniques are required.

### Future Features — Approved Concepts
- Equipment section in My Kitchen.
- Lightweight skill assessment.
- Multiple-protein meal support.
- Egg preparation and breakfast support.
- Spice KO and salt-layering training.
- Independently expandable inventory sections.
- Managed authentication.
- Household persistence.
- Stripe Checkout and Billing Portal integration.

### Roadmap Decisions
The next phase is a My Kitchen data-model decision phase before deeper website-to-planner integration. It must resolve ingredient specificity, inventory navigation, equipment capture, skill profile, persistence, and API payloads.

### Lessons Learned
- Separate public and Python services clarify responsibility.
- Render domain ownership must attach to the intended service.
- DNS and certificate caching can temporarily disguise correct configuration.
- Customer flows must not point to undeployed pages.
- Broad ingredient labels are useful for browsing but unsafe as universal cooking identities.

### Open Questions
1. Should each quadrant be a long collapsible stream, grouped subsections, search-first, or a combination?
2. How should broad labels such as Fresh Greens resolve to specific CKB ingredients?
3. May a broad family proceed to recipe generation without a specific ingredient?
4. How flexible should recipes be within a substitution family?
5. Which equipment fields are required in v1?
6. Should skill assessment be global or capability-specific?
7. How should exact quantity later coexist with None/A little/Plenty?
8. Which data belongs in signup versus later My Kitchen setup?

### Naming Decisions
- My Kitchen
- Pantry, Fridge, Freezer, Fresh, Equipment
- Log In
- Start Free Trial
- GetRecipeList
- GetRecipe

### Constitution Candidates
1. Broad display categories shall not be treated as technically interchangeable ingredients.
2. Food, equipment, and teaching preference shall remain separate data domains.
3. No cuisine selection shall invoke safe neutral seasoning rather than no seasoning.
4. Instructions shall derive from planner facts and schedule constraints.
5. Timing shall prefer observable gates and realistic windows.
6. Stripe shall retain payment-card responsibility.
7. Public site, authentication, household memory, planning, and payment shall remain separable layers.

### Chapter Summary
The project now has a real hosted customer journey and enters a deliberate household-data decision phase. The central unresolved issue is how to keep inventory simple for users while preserving the exact ingredient knowledge required for safe and useful cooking guidance.
