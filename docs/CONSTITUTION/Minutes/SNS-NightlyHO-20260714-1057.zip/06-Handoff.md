# Stock & Stir Handoff
## 2026-07-14

### Current Horizon
Horizon D is sufficiently complete for hosted demonstration. The project now enters a Household Data and Public Integration decision phase.

### Current Status
- Python app live on Render.
- Public static site live on stockandstir.co and www.stockandstir.co.
- Public and Python services are separate.
- Login/signup prototype functional.
- My Kitchen prototype functional.
- Pricing: seven-day trial, $10/month, $100/year.
- Regression suite: 67 passed.
- Latest tested version committed.
- Workspace clean.

### Today's Discoveries
- My Kitchen cannot scale as four flat grids.
- Each quadrant may need an independently expandable stream.
- Fresh Greens is too broad for cooking logic because kale, chard, spinach, and lettuce behave differently.
- The system needs Ingredient Family versus Specific Ingredient Identity.
- Equipment belongs in My Kitchen.
- Skill belongs in onboarding/profile.
- The next task is data-model design, not debugging.

### Files Most Likely to Change Next
- web/public-site/my-kitchen.html
- web/public-site/sns-flow.js
- web/public-site/sns-flow.css
- household/profile schema
- CKB ingredient/family schema
- API contract documentation
- GetRecipeList and GetRecipe endpoints
- authentication configuration

### Warnings
- Do not treat Fresh Greens as one universal planning ingredient.
- Do not connect the public site to ad hoc Streamlit session state.
- Do not add exact-inventory bureaucracy before validating broad quantity bands.
- Do not mix food, equipment, and skill records.
- Do not use browser-only storage as production authentication.
- Do not move the custom domain away from the public static service.
- Do not change Wix DNS without a verified infrastructure reason.

### Next Recommended Engineering Task
Hold a focused My Kitchen Data Model v1 decision session covering:
1. ingredient family versus specific identity;
2. collapsible streams, category groups, search, and selected-item summary;
3. inventory record fields;
4. equipment fields;
5. skill/teaching fields;
6. GetRecipeList payload;
7. household persistence;
8. whether broad families may proceed without a specific ingredient.

Expected deliverables:
- MyKitchenDataContract-v1.md
- proposed schema changes
- one example payload
- Fresh Greens decision table
- mobile wireframe decision

### Stopping Point
Safe handoff. The implementation is functional, committed, and clean. The Fresh Greens issue is a deliberate architecture question, not an unstable code state.
