# BUILD_NOTES.md Update

- Deployed the Python Streamlit service to Render.
- Deployed the public website as a separate Render Static Site.
- Connected stockandstir.co and www.stockandstir.co to the public static site with managed TLS.
- Added Render dependency/runtime configuration.
- Added public homepage, login/signup shell, trial pricing, My Kitchen prototype, recipe-choice prototype, recipe-display prototype, and Stripe page shells.
- Added mobile-menu account actions.
- Updated planner voice placement, prep timing behavior, and tough-beef simmer guidance.
- Regression suite passed 67 tests.
- Latest tested version was committed; workspace reported clean.
