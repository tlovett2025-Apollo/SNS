# Architecture.md Merge Update

## Layer Responsibilities

### Public Static Site
Owns marketing, pricing, login/trial entry, My Kitchen UI, recipe-choice display, recipe display, and structured API calls. It does not own cooking logic or card data.

### Authentication Layer
Owns account creation, login, password recovery, sessions, household ownership, and trial entitlement.

### Household Profile Layer
Owns food inventory, storage, quantity band, equipment, exclusions, and teaching preference.

### Python Planning Service
Owns candidate generation, ranking, CKB lookup, equipment routing, scheduling, and human instructions.

### Payment Layer
Owns Stripe Checkout creation, Billing Portal creation, and webhook-based entitlement updates.

## New Terminology
- My Kitchen
- Inventory Quadrants
- Equipment Section
- Teaching Profile
- Ingredient Family
- Specific Ingredient Identity
- Lead Protein
- Supporting Protein

## Data Flow
```text
Public Website
  → Authentication
  → Household Profile / My Kitchen
  → GetRecipeList
  → Opportunity Engine
  → Ranked Choices
  → GetRecipe
  → Planner + CKB + Equipment Manager
  → Schedule-derived Recipe
```

## Inventory Rule
A broad family may support browsing, but planning must use a specific ingredient or a controlled substitution family.

```text
Fresh Greens
  ├─ Spinach      quick wilt; late add
  ├─ Swiss chard  stems/leaves may separate
  ├─ Kale         sturdy; earlier cook
  └─ Lettuce      usually raw or minimal heat
```

## Engineering Rules
1. Version public payloads.
2. Include the ranking inventory snapshot in recipe-choice requests.
3. Include selected candidate plus relevant household state in recipe-generation requests.
4. Keep food, equipment, and teaching profile separate.
5. Use managed authentication.
6. Keep payment-card data with Stripe.
7. Deploy public and Python services independently.
8. Attach domains only to the intended Render service.
9. Never infer exact cooking behavior from a broad display family alone.
10. Distinguish lead and supporting proteins.

## Suggested Household Payload
```json
{
  "contract_version": "my-kitchen-v1",
  "household_id": "generated-id",
  "inventory": [
    {
      "ingredient_id": 123,
      "display_name": "Spinach",
      "family": "Fresh Greens",
      "storage": "Fresh",
      "form": "Fresh Raw",
      "amount": "little",
      "quantity_band": 1
    }
  ],
  "equipment": {
    "burners": 2,
    "oven": true,
    "microwave": true,
    "rice_cooker": false,
    "pressure_cooker": true
  },
  "teaching_profile": {
    "level": "learning"
  }
}
```
