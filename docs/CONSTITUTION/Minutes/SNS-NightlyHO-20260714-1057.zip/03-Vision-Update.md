# VISION.md Merge Additions

## Mission
Add that Stock & Stir remembers food, equipment, household constraints, and preferred teaching depth.

## Product Philosophy
Add:
- Broad user-facing language must not erase cooking differences.
- Encouragement supports a step rather than becoming a step.
- Honest timing uses observable doneness and realistic windows.
- No cuisine selection means neutral meal-appropriate seasoning, not no seasoning.

## Architecture
Add:
Public Website → Authentication → My Kitchen → Recipe Choices → Generated Recipe

Add separate persistent My Kitchen domains:
- food inventory;
- equipment;
- household preferences;
- teaching profile.

## User Experience
Add:
- My Kitchen uses Pantry, Fridge, Freezer, Fresh, and Equipment.
- Large sections should be independently expandable and searchable.
- Returning users enter saved My Kitchen; new users enter guided setup.
- Mobile navigation exposes login and trial actions in portrait mode.

## Business
Replace prior tiers with:
- seven-day free trial;
- $10/month;
- $100/year;
- one complete paid product.

## Roadmap
Add a formal My Kitchen data-model phase before deep website-to-planner integration.
