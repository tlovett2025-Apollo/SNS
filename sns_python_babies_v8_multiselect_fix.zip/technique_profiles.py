"""
Technique Profiles for SNS.
Technique babies know the general cooking method. Ingredient babies still decide
real timing and behavior for that method.
"""

from dataclasses import dataclass


def _clean(value):
    return "" if value is None else str(value).strip()


def _key(value):
    return _clean(value).lower().replace("-", " ")


@dataclass
class TechniqueProfile:
    name: str
    active_bias: int = 5
    passive_bias: int = 0
    attention_score: int = 5
    cleanup_score: int = 3
    description: str = ""


TECHNIQUES = {
    "skillet": TechniqueProfile("Skillet", active_bias=7, passive_bias=2, attention_score=6, cleanup_score=4, description="Stovetop cooking with regular attention."),
    "saute": TechniqueProfile("Saute", active_bias=8, passive_bias=0, attention_score=7, cleanup_score=3, description="Quick stovetop cooking with frequent movement."),
    "simmer": TechniqueProfile("Simmer", active_bias=2, passive_bias=8, attention_score=2, cleanup_score=2, description="Gentle cooking in liquid with mostly passive time."),
    "bake": TechniqueProfile("Bake", active_bias=2, passive_bias=9, attention_score=2, cleanup_score=3, description="Oven cooking with mostly passive time."),
    "roast": TechniqueProfile("Roast", active_bias=3, passive_bias=8, attention_score=2, cleanup_score=3, description="Dry oven heat with mostly passive time."),
    "reheat": TechniqueProfile("Reheat", active_bias=2, passive_bias=3, attention_score=1, cleanup_score=1, description="Warm prepared components."),
}


def get_technique_profile(name):
    k = _key(name)
    aliases = {
        "quick bowl": "skillet",
        "quick_bowl": "skillet",
        "kid adventure": "skillet",
        "kid_adventure": "skillet",
        "plate": "skillet",
        "handheld": "skillet",
        "casserole": "bake",
        "soup": "simmer",
        "sauté": "saute",
    }
    k = aliases.get(k, k)
    return TECHNIQUES.get(k, TECHNIQUES["skillet"])
