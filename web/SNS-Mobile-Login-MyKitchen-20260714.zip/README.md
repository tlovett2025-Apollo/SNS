# Mobile Login + My Kitchen Destination

Changed/deployment files:

- `index.html`
  - Mobile menu order:
    - How It Works
    - Features
    - Meal Ideas
    - Pricing
    - Log In
    - Start Free Trial
    - About Us
  - Desktop header buttons remain unchanged.

- `login.html`
  - Prototype login/signup form.
  - After valid prototype submission, routes to `my-kitchen.html`.

- `my-kitchen.html`
- `sns-flow.css`
- `sns-flow.js`
  - These provide the actual My Kitchen destination so login no longer lands on a missing black/404 page.

Install all five files in `web/public-site`, replacing files with the same names. Then commit and push.

Prototype behavior after account information is entered:
1. Validate required fields and matching signup passwords.
2. Save only temporary prototype session information in the browser.
3. Open My Kitchen.
4. Real authentication, household ownership, trial dates, and Stripe status will later be handled by managed backend services.
