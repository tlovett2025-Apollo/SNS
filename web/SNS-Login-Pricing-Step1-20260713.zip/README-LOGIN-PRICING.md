# SNS Login + Pricing — Step 1

Trial decision: **7 days**.

Pricing:
- Monthly: **$10/month** (about **$0.33/day**).
- Annual: **$100/year** (about **$0.27/day**).

Files:
- `login.html` — login / signup shell; signup routes to `my-kitchen.html`.
- `homepage-auth-pricing.js` — rewires homepage CTAs and replaces the pricing section.

Install:
1. Copy both files into `web/public-site`.
2. Add this immediately before `</body>` in `web/public-site/index.html`:

   `<script src="homepage-auth-pricing.js"></script>`

3. Commit and push. Render will redeploy the static site.

This is a visual first step only. It does not store passwords or create real accounts.
