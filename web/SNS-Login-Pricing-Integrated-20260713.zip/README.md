# Integrated Login + Pricing

Files are based on the exact current `index.html` supplied by Tracy.

Changes:
- 7-day free trial.
- $10/month.
- $100/year.
- Annual equivalent shown as about $0.27/day.
- Monthly equivalent shown as about $0.33/day.
- Homepage Log In and signup CTAs route to `login.html`.
- New login/signup shell routes successful prototype submission to `my-kitchen.html`.

Install:
1. Copy `index.html` and `login.html` into `web/public-site`.
2. Replace the existing `index.html`.
3. Commit and push.
